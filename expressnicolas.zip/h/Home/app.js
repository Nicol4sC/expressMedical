const express = require('express');
const app = express();
const port = 10000; 
app.get('/', (req, res) => {
res.sendFile(__dirname + '/homepage.html');
});

app.get('/outra_pagina', (req, res) => {
res.sendFile(__dirname + '/outra_pagina.html');
});

app.use(express.static(__dirname + '/'));
app.listen(port, () => {
console.log(`Servidor Express está rodando na porta ${port}`);
});
